<?php
namespace helpdesk\forms;

use std, gui, framework, helpdesk;
use php\gui\event\UXEvent; 


class setting extends AbstractForm
{

    /**
     * @event close 
     */
    function doClose(UXWindowEvent $e = null)
    {    
        
    }

    /**
     * @event goFuture2.action 
     */
    function doGoFuture2Action(UXEvent $e = null)
    {    
        
    }




}
