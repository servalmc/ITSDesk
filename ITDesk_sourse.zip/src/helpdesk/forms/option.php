<?php
namespace helpdesk\forms;
use std, gui, framework, helpdesk;

use php\io\Stream;
use php\util\Scanner;
use php\io\IOException;
use php\gui\event\UXEvent; 
use action\Element; 
use php\gui\event\UXMouseEvent;

class option extends AbstractForm
{

    /**
     * @event cname.construct 
     */
    function doCnameConstruct(UXEvent $e = null)
    {
        
        $myname = $this->ini->get('username','setting');
        // Generated
        $e = $event ?: $e;
        
        Element::setText($e->sender, $myname);
    }

    /**
     * @event cemail.construct 
     */
    function doCemailConstruct(UXEvent $e = null)
    {
        
        $myemail = $this->ini->get('useremail','setting');
        // Generated
        $e = $event ?: $e;
        
        Element::setText($e->sender, $myemail);
    }

    /**
     * @event cid.construct 
     */
    function doCidConstruct(UXEvent $e = null)
    {
        $myid = $this->ini->get('userid','setting');
        
        // Generated
        $e = $event ?: $e;
        
        Element::setText($e->sender, $myid);
    }

    /**
     * @event cphone.construct 
     */
    function doCphoneConstruct(UXEvent $e = null)
    {
        $myphone = $this->ini->get('userphone','setting');
        
        // Generated
        $e = $event ?: $e;
        
        Element::setText($e->sender, $myphone);
    }

    /**
     * @event ctoken.construct 
     */
    function doCtokenConstruct(UXEvent $e = null)
    {
        $mytoken = $this->ini->get('tgtoken','setting');
        
        // Generated
        $e = $event ?: $e;
        
        Element::setText($e->sender, $mytoken);
    }

    /**
     * @event cchatid.construct 
     */
    function doCchatidConstruct(UXEvent $e = null)
    {
        $mychat = $this->ini->get('tgchatid','setting');
        
        // Generated
        $e = $event ?: $e;
        
        Element::setText($e->sender, $mychat);
    }

    /**
     * @event cserver.construct 
     */
    function doCserverConstruct(UXEvent $e = null)
    {
        $myserver = $this->ini->get('mailurl','setting');
        
        // Generated
        $e = $event ?: $e;
        
        Element::setText($e->sender, $myserver);
    }

    /**
     * @event goFuture.action 
     */
    function doGoFutureAction(UXEvent $e = null)
    {
    
    }
    
    /**
     * @event serveremails.construct 
     */
    function doServeremailsConstruct(UXEvent $e = null)
    {
        $servmail = $this->ini->get('serveremail','setting');
        
        // Generated
        $e = $event ?: $e;
        
        Element::setText($e->sender, $servmail);
    }

    /**
     * @event saveINI.action 
     */
    function doSaveINIAction(UXEvent $e = null)
    {
        $cname = $this->cname->text;
        $this->ini->set('username', $cname,'setting');
        $cemail = $this->cemail->text;
        $this->ini->set('useremail', $cemail,'setting');
        $cid = $this->cid->text;
        $this->ini->set('userid', $cid,'setting');
        $cphone = $this->cphone->text;
        $this->ini->set('userphone', $cphone,'setting');
        $ctoken = $this->ctoken->text;
        $this->ini->set('tgtoken', $ctoken,'setting');
        $cchatid = $this->cchatid->text;
        $this->ini->set('tgchatid', $cchatid,'setting');
        $cserver = $this->cserver->text;
        $this->ini->set('mailurl', $cserver,'setting');
        $servermail = $this->serveremails->text;
        $this->ini->set('serveremail', $servermail,'setting');
        alert('Настройки сохранены!');
    }


}
