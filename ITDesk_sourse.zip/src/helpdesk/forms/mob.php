<?php
namespace helpdesk\forms;

use std, gui, framework, helpdesk;
use php\gui\event\UXEvent; 


class mob extends AbstractForm
{

    /**
     * @event link.action 
     */
    function doLinkAction(UXEvent $e = null)
    {    
        
    }

    /**
     * @event goFuture3.action 
     */
    function doGoFuture3Action(UXEvent $e = null)
    {    
        
    }

}
