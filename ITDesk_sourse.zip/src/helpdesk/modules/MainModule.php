<?php
namespace helpdesk\modules;

use std, gui, framework, helpdesk;


class MainModule extends AbstractModule
{

}
