<?php
namespace helpdesk\modules;

use bundle\updater\UpdateMe;
use std, gui, framework, helpdesk;


class AppModule extends AbstractModule
{
    
    /**
     * @var string 
     */
    public $lockFile = 'app.lock';
    
    /**
     * Запуск программы
     * @event action  
     */
    public function сonstruct(){           
        
        // Создаём папку для прорграммы в домашней директории текущего пользователя (туда всегда разрешена запись)
        $app_dir = $this->getAppDir();       
        if(!fs::exists($app_dir)){
            fs::makeDir($app_dir);
        }
        
                
        $this->singleRun();
        
    }
    
    public function singleRun(){
        /* @var File $file */
        $file = File::of($this->getAppDir() . $this->lockFile);
        if($file->exists()){
            if(!$file->delete()){
                alert('Программа уже запущена! Возможна работа только одной копии программы.');
                $this->shutdown();
            }
        }
        
        $file->createNewFile();
        $stream = FileStream::of($file->getAbsolutePath(), 'w');
        $stream->write(1);
    }
    
    
    public function getAppDir(){
        $ds = System::getProperty('file.separator');
        return System::getProperty('user.home') . $ds . 'ITSDesk'. $ds;
    }    
    
    
    public function getCurrentDir() : string {
        $ds = System::getProperty('file.separator');
        $path = System::getProperty("java.class.path");
        $sep = System::getProperty("path.separator");
        return dirname(realpath(str::split($path, $sep)[0])) . $ds;
    } 

}
