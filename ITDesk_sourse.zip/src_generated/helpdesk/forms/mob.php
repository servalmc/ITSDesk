<?php
namespace helpdesk\forms;

use std, gui, framework, helpdesk;
use php\gui\event\UXEvent; 


class mob extends AbstractForm
{

    /**
     * @event link.action 
     */
    function doLinkAction(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		browse('https://itsys.kz/mob');

        
    }

    /**
     * @event goFuture3.action 
     */
    function doGoFuture3Action(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		$this->loadForm('MainForm', true, true);

        
    }

}
