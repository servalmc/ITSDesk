<?php
namespace helpdesk\forms;

use std, gui, framework, helpdesk;
use php\gui\event\UXEvent; 
use action\Element; 
use php\io\Stream; 


class setting extends AbstractForm
{

    /**
     * @event close 
     */
    function doClose(UXWindowEvent $e = null)
    {    
        
    }

    /**
     * @event goFuture2.action 
     */
    function doGoFuture2Action(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		$this->loadForm('MainForm', true, true);

        
    }




}
