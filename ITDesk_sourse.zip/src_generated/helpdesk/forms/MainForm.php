<?php
namespace helpdesk\forms;

use bundle\windows\Registry;
use bundle\updater\UpdateMe;
use std, gui, framework, helpdesk;

use php\io\Stream;
use php\util\Scanner;
use php\io\IOException;
use php\gui\event\UXEvent; 
use action\Element; 
use php\gui\event\UXMouseEvent;


class MainForm extends AbstractForm
{

    const VERSION = '3.0.0.0';
     
    
    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        // Проверка обновлений
        // Обязательно нужно передать текущую версию программы
        UpdateMe::start(self::VERSION);
    }

    /**
     * @event email.construct 
     */
    function doEmailConstruct(UXEvent $e = null)
    {
        
        $useremail = $this->ini->get('useremail','setting');
        // Generated
        $e = $event ?: $e; // legacy code from 16 rc-2
        
        Element::setText($e->sender, $useremail);
    }

    /**
     * @event name.construct 
     */
    function doNameConstruct(UXEvent $e = null)
    {
        $username = $this->ini->get('username','setting');
        // Generated
        $e = $event ?: $e;
        Element::setText($this->name, $username);
        
    }

    /**
     * @event numcab.construct 
     */
    function doNumcabConstruct(UXEvent $e = null)
    {
        $userid = $this->ini->get('userid','setting');
        
        // Generated
        $e = $event ?: $e; // legacy code from 16 rc-2
        
        Element::setText($e->sender, $userid);
    }




    /**
     * @event close 
     */
    function doClose(UXWindowEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		app()->hideForm('chat');
		app()->hideForm('setting');
		app()->hideForm('mob');

        
    }
    
    
    /**
     * @event goMessage.action 
     **/
    function doGoMessageAction(UXEvent $event = null)
    {    
        
        //Данные для отправки...
        $email = $this->email->text;
        $phone = urlencode($this->phone->text);
        $name = urlencode($this->name->text);
        $numcab = $this->numcab->text;
        $topic = urlencode($this->topic->selectedIndex);
        $mesag = urlencode($this->mesag->text);
        $tg_token = $this->ini->get('tgtoken','setting');
        $tg_chat = $this->ini->get('tgchatid','setting');
        $mailurl = $this->ini->get('mailurl','setting');
        $tvidtxt = $this->tvid->text;
        $smail = $this->ini->get('serveremail','setting');;
        
        //Посылаем запрос с параметрами...
        if($topic == 0):
        $messag = "Не включается компьютер";
    elseif($topic == 1):
        $messag = "Нет интернета";
    elseif($topic == 2):
        $messag = "Не работает программа";
    elseif($topic == 3):
        $messag = "Компьютер работает нестабильно";
    elseif($topic == 4):
        $messag = "Вирусное заражение";
    elseif($topic == 5):
        $messag = "Проблемы с IIKO";
    elseif($topic == 6):
        $messag = "Проблемы с 1С";
    elseif($topic == 7):
        $messag = "Проблемы с Кабинетом Налогоплательщика или SONO";
    elseif($topic == 8):
        $messag = "Проблемы с оргтехникой (принтеры, мфу и сканеры)";
    elseif($topic == 9):
        $messag = "Прокладка сетевого и телефонного кабеля";
    elseif($topic == 10):
        $messag = "Установка новой техники";
    elseif($topic == 11):
        $messag = "Консультирование по вопросам ИТ";
    elseif($topic == 12):
        $messag = "Установка программ";
    else:
        $messag = "Другое";
    endif;

        $messages = '<b>Заявка от:</b> '.$name.'<br><b>E-mail:</b> '.$email.'<br><b>ID компьютера:</b> '.$numcab.'<br><b>Проблема:</b> '.$messag.'<br><b>Подробно:</b> '.$mesag.'<br><b>Телефон:</b> '.$phone.'<br><b>Источник:</b> Приложение для ПК';
        $sourse = 'Приложение для ПК';
         // Данные для отправки...
        $key = '31415926535';
        // От кого отпровляем?;
        $from = $email;
        // Кому отпровляем?;
        $to = $smail;


        $text_meg = "Заявка от: ".$name."\nE-mail: ".$email."\nID компьютера: ".$numcab."\nПроблема: ".$messag."\nПодробно: ".$mesag."\nТелефон: ".$phone."\nTV ID: ".$tvidtxt."\nИсточник: ".$sourse;
        $subject = urlencode($messag);
        $message = urlencode($text_meg);

        //Посылаем запрос с параметрами...
        $request = file_get_contents($mailurl.'?to=' . $to . '&from=' . $from . '&subject=' . $subject . '&message=' . $message . '&key=' . $key);

        
        $tg= file_get_contents('https://api.telegram.org/bot'.$tg_token.'/sendMessage?chat_id='.$tg_chat.'&text=Новая%20заявка!%0AЗаявка%20от%20'.$name.'%0AClient%20ID:%20'.$numcab.'%0AПроблема:%20'.$messag.'%0AТелефон:%20'.$phone.'%0AПодробно:%0A'.$mesag.'%0ATV%20ID:%20'.$tvidtxt.'%0AИсточник:%20Приложение для ПК');
        //Делаем проверку на true или false...
        if ($request == '1'){
            alert('Заявка успешно отправлена1!');
        }else{
            alert('Заявка успешно отправлена!');
        }
    }


    /**
     * @event phone.construct 
     */
    function doPhoneConstruct(UXEvent $e = null)
    {
        $userphone = $this->ini->get('userphone','setting');
        
        // Generated
        $e = $event ?: $e; // legacy code from 16 rc-2
        
        Element::setText($e->sender, $userphone);
    }


    /**
     * @event tvid.construct 
     */
    function doTvidConstruct(UXEvent $e = null)
    {
        if (PHP_INT_SIZE === 4) { $regid = 'HKEY_LOCAL_MACHINE\SOFTWARE\TeamViewer'; } else { $regid = 'HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\TeamViewer'; }
        $version = Registry::of($regid)->read('ClientID')->value;
        $tvidcmd = str_replace("0x", "", $version);
        $tvid = hexdec($tvidcmd);
        
        // Generated
        $e = $event ?: $e; // legacy code from 16 rc-2
        
        Element::setText($e->sender, $tvid);
    }

    /**
     * @event optionb.action 
     */
    function doOptionbAction(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		$this->loadForm('setting', true, true);

        
    }

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		$this->loadForm('option', true, true);

        
    }

    /**
     * @event gplay.action 
     */
    function doGplayAction(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		$this->loadForm('mob', true, true);

        
    }

}
